<a href="<?php the_permalink();?>" itemprop="url">
    <?php the_post_thumbnail('large'); ?>
</a>